import React, { useState } from 'react'
import toastr from 'toastr'
import 'toastr/build/toastr.min.css'

const CONTACT_EMAIL = 'lovelygutierrez491@gmail.com'

const projects = [
  {
    number: '一',
    title: 'Personal Portfolio',
    japanese: 'ポートフォリオ',
    description:
      'A personal portfolio showcasing my background, skills, academic journey, and selected creative work through a clean sakura-inspired design.',
    tags: ['React', 'Vite', 'CSS'],
  },
  {
    number: '二',
    title: 'MachineProblem-Queue',
    japanese: 'チケットキュー',
    description:
      'A Java-based IT Support Ticketing System that uses a queue to accept support tickets, process them in first-in-first-out order, and display any remaining requests.',
    tags: ['Java', 'Queue', 'Data Structures'],
  },
  {
    number: '三',
    title: 'Bookstore Inventory Management System',
    japanese: '書店在庫管理',
    description:
      'A console-based Java application for managing books and customer orders using linked lists, queues, bubble sorting, and linear searching.',
    tags: ['Java', 'Linked List', 'Algorithms'],
  },
]

const sakuraBlossoms = [
  'one',
  'two',
  'three',
  'four',
  'five',
  'six',
  'seven',
]

const fallingPetals = Array.from({ length: 12 }, (_, index) => index + 1)

toastr.options = {
  closeButton: true,
  newestOnTop: true,
  progressBar: true,
  positionClass: 'toast-top-right',
  preventDuplicates: true,
  timeOut: 5000,
  extendedTimeOut: 1500,
  showDuration: 250,
  hideDuration: 250,
  showMethod: 'fadeIn',
  hideMethod: 'fadeOut',
}

function SakuraBlossom({ position }) {
  return (
    <span className={`sakura-blossom sakura-blossom--${position}`}>
      {[0, 1, 2, 3, 4].map((petal) => (
        <i key={petal}></i>
      ))}
      <b></b>
    </span>
  )
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [fieldErrors, setFieldErrors] = useState({})
  const [formStatus, setFormStatus] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  const closeMenu = () => setMenuOpen(false)

  const clearFieldError = (fieldName) => {
    setFieldErrors((currentErrors) => {
      if (!currentErrors[fieldName]) {
        return currentErrors
      }

      const updatedErrors = { ...currentErrors }
      delete updatedErrors[fieldName]
      return updatedErrors
    })
  }

  const handleSubmit = (event) => {
    event.preventDefault()

    const form = event.currentTarget

    setFieldErrors({})
    setFormStatus('')

    try {
      const formData = new FormData(form)

      const name = String(formData.get('name') || '').trim()
      const email = String(formData.get('email') || '').trim()
      const message = String(formData.get('message') || '').trim()

      const errors = {}

      if (!name) {
        errors.name = 'Please enter your name.'
      } else if (name.length < 2) {
        errors.name = 'Your name must contain at least 2 characters.'
      }

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i

      if (!email) {
        errors.email = 'Please enter your email address.'
      } else if (!emailPattern.test(email)) {
        errors.email = 'Please enter a valid email address.'
      }

      if (!message) {
        errors.message = 'Please enter your message.'
      } else if (message.length < 10) {
        errors.message = 'Your message must contain at least 10 characters.'
      }

      if (Object.keys(errors).length > 0) {
        setFieldErrors(errors)
        setFormStatus('Please correct the highlighted fields.')

        toastr.clear()
        toastr.error(
          'Check the highlighted fields, then try again.',
          'Unable to submit message',
        )

        const firstInvalidField = Object.keys(errors)[0]
        form.elements[firstInvalidField]?.focus()
        return
      }

      setIsSubmitting(true)

      window.setTimeout(() => {
        form.reset()
        setFieldErrors({})
        setFormStatus('Thank you for sending an email.')
        setIsSubmitting(false)

        toastr.clear()
        toastr.success(
          'Thank you for sending an email.',
          'Message submitted',
        )
      }, 600)
    } catch (error) {
      console.error('Contact form error:', error)
      setIsSubmitting(false)
      setFormStatus('Something went wrong. Please try again.')

      toastr.clear()
      toastr.error(
        'Something went wrong while submitting the form. Please try again.',
        'Submission failed',
      )
    }
  }

  return (
    <div className="site-shell">
      <header className="site-header">
        <a className="brand" href="#home" onClick={closeMenu}>
          <span className="brand-mark">桜</span>

          <span>
            LAUV.LEE
            <small>ポートフォリオ</small>
          </span>
        </a>

        <button
          className="menu-button"
          type="button"
          aria-label="Toggle navigation"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((current) => !current)}
        >
          {menuOpen ? '閉じる' : 'メニュー'}
        </button>

        <nav className={menuOpen ? 'site-nav site-nav--open' : 'site-nav'}>
          <a href="#about" onClick={closeMenu}>
            About
          </a>

          <a href="#projects" onClick={closeMenu}>
            Projects
          </a>

          <a href="#contact" onClick={closeMenu}>
            Contact
          </a>
        </nav>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="hero-copy">
            <p className="kicker">こんにちは · Welcome to my portfolio</p>

            <h1>
              Simple ideas,
              <span> thoughtfully made.</span>
            </h1>

            <p className="hero-description">
              I am <strong>Lauv Lee</strong>, a 22-year-old BSCS student from
              Sabang, Lipa City, currently working at Stallion Realty.
            </p>

            <div className="hero-actions">
              <a className="button button--primary" href="#about">
                Discover my story
              </a>

              <a className="button button--ghost" href="#contact">
                Contact me
              </a>
            </div>
          </div>

          <div
            className="hero-art"
            aria-label="Sakura-inspired Lauv Lee monogram artwork"
          >
            <div className="sun" aria-hidden="true"></div>

            <div className="sakura-scene" aria-hidden="true">
              <span className="sakura-branch sakura-branch--main"></span>
              <span className="sakura-branch sakura-branch--small"></span>

              {sakuraBlossoms.map((blossom) => (
                <SakuraBlossom key={blossom} position={blossom} />
              ))}
            </div>

            <div className="falling-petals" aria-hidden="true">
              {fallingPetals.map((petal) => (
                <span
                  className={`falling-petal falling-petal--${petal}`}
                  key={petal}
                ></span>
              ))}
            </div>

            <div className="portrait-frame">
              <span className="vertical-copy">静けさ · 創造 · 成長</span>
              <div className="monogram">LL</div>
              <p>Sabang · Lipa City</p>
            </div>

            <div className="brush-line brush-line--one"></div>
            <div className="brush-line brush-line--two"></div>
          </div>
        </section>

        <section className="section about" id="about">
          <div className="section-title">
            <span className="section-number">01</span>

            <div>
              <p>私について</p>
              <h2>About Me</h2>
            </div>
          </div>

          <div className="about-layout">
            <div className="about-story">
              <p className="lead">
                I am a Bachelor of Science in Computer Science student who
                values calm, purposeful, and well-organized work.
              </p>

              <p>
                I am 22 years old and based in Sabang, Lipa City. Alongside my
                studies, I work at Stallion Realty, where I continue to gain
                practical experience and develop my professional skills.
              </p>

              <p>
                This portfolio presents my background, selected work, and the
                ways people can connect with me.
              </p>
            </div>

            <dl className="profile-details">
              <div>
                <dt>Age</dt>
                <dd>22 years old</dd>
              </div>

              <div>
                <dt>Program</dt>
                <dd>BS Computer Science</dd>
              </div>

              <div>
                <dt>Location</dt>
                <dd>Sabang, Lipa City</dd>
              </div>

              <div>
                <dt>Work</dt>
                <dd>Stallion Realty</dd>
              </div>
            </dl>
          </div>
        </section>

        <section className="section projects" id="projects">
          <div className="section-title">
            <span className="section-number">02</span>

            <div>
              <p>作品</p>
              <h2>Projects</h2>
            </div>
          </div>

          <div className="project-grid">
            {projects.map((project) => (
              <article className="project-card" key={project.title}>
                <div className="project-topline">
                  <span>{project.number}</span>
                  <small>{project.japanese}</small>
                </div>

                <h3>{project.title}</h3>
                <p>{project.description}</p>

                <div className="tags">
                  {project.tags.map((tag) => (
                    <span key={tag}>{tag}</span>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="section contact" id="contact">
          <div className="section-title section-title--light">
            <span className="section-number">03</span>

            <div>
              <p>連絡先</p>
              <h2>Contact Me</h2>
            </div>
          </div>

          <div className="contact-layout">
            <div className="contact-intro">
              <p className="contact-quote">
                Let us create something meaningful.
              </p>

              <p>
                Reach me through phone, email, or Instagram. Complete the form
                below and make sure your contact details are correct.
              </p>

              <div className="contact-links">
                <a href="tel:+639931853041">
                  <span>Phone</span>
                  0993 185 3041
                </a>

                <a href={`mailto:${CONTACT_EMAIL}`}>
                  <span>Email</span>
                  {CONTACT_EMAIL}
                </a>

                <a
                  href="https://www.instagram.com/ilauv.lee"
                  target="_blank"
                  rel="noreferrer"
                >
                  <span>Instagram</span>
                  @ilauv.lee
                </a>
              </div>
            </div>

            <form className="contact-form" onSubmit={handleSubmit} noValidate>
              <label htmlFor="contact-name">
                Your name

                <input
                  id="contact-name"
                  name="name"
                  type="text"
                  placeholder="Enter your name"
                  autoComplete="name"
                  minLength="2"
                  aria-invalid={Boolean(fieldErrors.name)}
                  aria-describedby={
                    fieldErrors.name ? 'contact-name-error' : undefined
                  }
                  className={fieldErrors.name ? 'input-error' : ''}
                  onChange={() => clearFieldError('name')}
                />

                {fieldErrors.name && (
                  <span
                    className="field-error"
                    id="contact-name-error"
                    role="alert"
                  >
                    {fieldErrors.name}
                  </span>
                )}
              </label>

              <label htmlFor="contact-email">
                Your email

                <input
                  id="contact-email"
                  name="email"
                  type="email"
                  placeholder="name@example.com"
                  autoComplete="email"
                  aria-invalid={Boolean(fieldErrors.email)}
                  aria-describedby={
                    fieldErrors.email ? 'contact-email-error' : undefined
                  }
                  className={fieldErrors.email ? 'input-error' : ''}
                  onChange={() => clearFieldError('email')}
                />

                {fieldErrors.email && (
                  <span
                    className="field-error"
                    id="contact-email-error"
                    role="alert"
                  >
                    {fieldErrors.email}
                  </span>
                )}
              </label>

              <label htmlFor="contact-message">
                Message

                <textarea
                  id="contact-message"
                  name="message"
                  rows="5"
                  placeholder="Write your message"
                  minLength="10"
                  aria-invalid={Boolean(fieldErrors.message)}
                  aria-describedby={
                    fieldErrors.message ? 'contact-message-error' : undefined
                  }
                  className={fieldErrors.message ? 'input-error' : ''}
                  onChange={() => clearFieldError('message')}
                ></textarea>

                {fieldErrors.message && (
                  <span
                    className="field-error"
                    id="contact-message-error"
                    role="alert"
                  >
                    {fieldErrors.message}
                  </span>
                )}
              </label>

              <button
                className="button button--paper"
                type="submit"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Submitting...' : 'Send message'}
              </button>

              <p className="form-note">
                Your details will be checked before the form is accepted.
              </p>

              <p className="sr-only" aria-live="polite">
                {formStatus}
              </p>
            </form>
          </div>
        </section>
      </main>

      <footer>
        <p>© {new Date().getFullYear()} Lauv Lee</p>
      </footer>
    </div>
  )
}

export default App